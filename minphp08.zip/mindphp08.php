<?php
require_once('tcpdf.php');

$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8');

$pdf->SetCreator('Mindphp');
$pdf->SetAuthor('Mindphp Developer');
$pdf->SetTitle('Mindphp Example 08');
$pdf->SetSubject('Mindphp Example');
$pdf->SetKeywords('Mindphp, TCPDF, PDF, example, guide');

$pdf->setHeaderFont(array('freeserif', 'B', 12));
$pdf->SetHeaderData('mindphp.png', 20, 'Mindphp Example 08', 'การจัดหน้าแบบหลายรูปแบบในเอกสารเดียว', array (0, 64, 255), array (0, 64, 128));
$pdf->setFooterData(array (0, 64, 0), array (0, 64, 128));

$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetFont('freeserif', '', 100);
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// เพิ่มหน้าเอกสาร
// P = กำหนดให้เป็นแนวตั้ง
// A0 = กำหนดขนาดของกระดาษ
$pdf->AddPage('P', 'A0');
$pdf->Cell(0, 0, 'A0 แนวตั้ง', 0, 0, 'C');

// เพิ่มหน้าเอกสาร
// L = กำหนดให้เป็นแนวนอน
// A1 = กำหนดขนาดของกระดาษ
$pdf->AddPage('L', 'A1');
$pdf->Cell(0, 0, 'A1 แนวนอน', 1, 1, 'C');

// เพิ่มหน้าเอกสาร
// P = กำหนดให้เป็นแนวตั้ง
// A2 = กำหนดขนาดของกระดาษ
$pdf->AddPage('P', 'A2');
$pdf->Cell(0, 0, 'A2 แนวตั้ง', 1, 1, 'C');

// เพิ่มหน้าเอกสาร
// L = กำหนดให้เป็นแนวนอน
// A3 = กำหนดขนาดของกระดาษ
$pdf->AddPage('L', 'A3');
$pdf->Cell(0, 0, 'A3 แนวนอน', 1, 1, 'C');

// เพิ่มหน้าเอกสาร
// P = กำหนดให้เป็นแนวตั้ง
// A4 = กำหนดขนาดของกระดาษ
$pdf->AddPage('P', 'A4');
$pdf->Cell(0, 0, 'A4 แนวตั้ง', 1, 1, 'C');

// เพิ่มหน้าเอกสาร
// L = กำหนดให้เป็นแนวนอน
// A5 = กำหนดขนาดของกระดาษ
$pdf->AddPage('L', 'A5');
$pdf->Cell(0, 0, 'A5 แนวนอน', 1, 1, 'C');

$pdf->Output('mindphp08.pdf', 'I');